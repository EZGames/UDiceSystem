package func.java.controlflow;

import java.util.ArrayList;
import java.util.concurrent.Callable;

// TODO: document and test
/**
 * 
 * <p>
 * <b>Example Usage:</b><br>
 * <code>
 * switch_()<br>
 *	&nbsp;&nbsp; .case_(x < 3)<br>
 *	&nbsp;&nbsp; &nbsp;&nbsp; .then_(Example::dealWithX)<br>
 *	&nbsp;&nbsp; &nbsp;&nbsp; .continue_()<br>
 *	&nbsp;&nbsp; .case_(x == 5)<br>
 *	&nbsp;&nbsp; &nbsp;&nbsp; .then_(Example::dealWithY)<br>
 *	&nbsp;&nbsp; &nbsp;&nbsp; .then_(() -> x++)<br>
 *	&nbsp;&nbsp; &nbsp;&nbsp; .continue_()<br>
 *	&nbsp;&nbsp; .default_()<br>
 *	&nbsp;&nbsp; &nbsp;&nbsp; .then_(Example::dealWithZ)<br>
 *	.go_();
 * </code>
 * </p>
 * <b>Note:</b>
 * <p>
 * The methods all have a postfix underscore because, unfortunately, they almost
 * all have the same name as a Java keyword. I tried several workarounds, but 
 * eventually settled on this.  To read how I came to this, read the backstory.</p>
 * <b>Backstory:</b>
 * <p>
 * I started with silly spellings,(sort of how Java stuff uses {@code clazz} as the
 * name of a {@code Class} object), such as {@code swish} instead of {@code switch},
 * {@code kase} instead of {@code case}, etc.</p>
 * <p>
 * Then I tried just capitalizing the names, but I didn't like the break from
 * Java convention.  Then I tried prefixing with an underscore, which was okay,
 * especially since it had the added benefit of listing all the useful methods
 * before the built-in {@code Object} methods when getting the list of all the
 * methods.  But it just looked wrong when looking at it in use.  I tried using
 * postfix underscores, and those seemed to almost disappear when looking at them, 
 * so I stuck with that.</p>
 */
public class ParameterlessSwitch
{
	//***************************************************************************
	// Public static factory methods
	//***************************************************************************
	public static ParameterlessSwitch switch_()
	{
		return new ParameterlessSwitch();
	}
	
	//***************************************************************************
	// Public API methods
	//***************************************************************************
	public NormalCase case_(Callable<Boolean> expr)
	{
		return new NormalCase(expr, this);
	}
	
	public DefaultCase default_()
	{
		if(defCase == null)
			return new DefaultCase(this);
		else
			throw new IllegalStateException("ParameterlessSwitch cannot have more than one default statement");
	}
	
	public void go_()
	{
		run(cases.toArray(new NormalCase[cases.size()]), 0);
	}
	
	//***************************************************************************
	// Internal use methods
	//***************************************************************************
	void addCase(NormalCase kase)
	{
		cases.add(kase);
	}
	
	void setDefaultCase(DefaultCase deFault)
	{
		defCase = deFault;
	}
	
	// *** private helpers *******************************************************
	private void run(NormalCase[] arr, int currIndex)
	{
		if(currIndex < arr.length)
		{
			NormalCase nCase = arr[currIndex];
			if(nCase.isTrue())
			{
				nCase.runAction();
				if(nCase.continues())
				{
					cuntinue(arr, currIndex + 1);
				}
			}
			else
			{
				run(arr, currIndex + 1);
			}
		}
		else if (defCase != null)
		{
			defCase.runAction();
		}
	}
	
	private void cuntinue(NormalCase[] arr, int currIndex)
	{
		if(currIndex < arr.length)
		{
			NormalCase nCase = arr[currIndex];
			nCase.runAction();
			if(nCase.continues())
			{
				cuntinue(arr, currIndex + 1);
			}
		}
		else if(defCase != null)
		{
			defCase.runAction();
		}
	}
	
	
	//***************************************************************************
	// Private constructor
	//***************************************************************************
	private ParameterlessSwitch()
	{
		cases = new ArrayList<>();
	}
	
	//***************************************************************************
	// Private fields
	//***************************************************************************
	private ArrayList<NormalCase> cases;
	private DefaultCase defCase;
}