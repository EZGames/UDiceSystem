package func.java.controlflow;

import java.util.concurrent.Callable;

// TODO document and test
class NormalCase
{
	//***************************************************************************
	// Public constructor
	//***************************************************************************
	public NormalCase(Callable<Boolean> expr, ParameterlessSwitch switch_)
	{
		boolExpr = expr;
		this.switch_ = switch_;
		continues = false;
		action = null;
	}
	
	//***************************************************************************
	// Public API methods
	//***************************************************************************
	public NormalCase then_(Runnable action)
	{
		if(this.action == null)
			this.action = action;
		else
		{
			//tack the new action on after the old one
			final Runnable oldAction = this.action;
			final Runnable newAction = action;
			this.action = new Runnable() {
					public void run()
					{
						oldAction.run();
						newAction.run();
					}
				};
		}
		return this;
	}
	
	public ParameterlessSwitch continue_()
	{
		continues = true;
		switch_.addCase(this);
		return switch_;
	}
	
	public NormalCase case_(Callable<Boolean> expr)
	{
		switch_.addCase(this);
		return switch_.case_(expr);
	}
	
	public DefaultCase default_()
	{
		switch_.addCase(this);
		return switch_.default_();
	}
	
	public void go_()
	{
		if(action == null)
		{
			throw new IllegalStateException("Cannot finish a ParameterlessSwitch with a case that has no action to perform");
		}
		switch_.addCase(this);
		switch_.go_();
	}
	
	//***************************************************************************
	// Internal use methods
	//***************************************************************************
	boolean isTrue()
	{
		try
		{
			return boolExpr.call();
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}
	
	void runAction()
	{
		if(action == null)
			return;
		else
			action.run();
	}
	
	boolean continues()
	{
		return continues;
	}
	
	//***************************************************************************
	// Private fields
	//***************************************************************************
	private ParameterlessSwitch switch_;
	private Callable<Boolean> boolExpr;
	private Runnable action;
	private boolean continues;
}
