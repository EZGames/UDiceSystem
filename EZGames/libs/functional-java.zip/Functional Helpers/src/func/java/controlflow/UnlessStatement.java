package func.java.controlflow;

/**
 * {@code Unless} is a simple alternative to writing a statement like:
 * <p>
 * <code>
 * if(!booleanExpression)<br>
 * &nbsp; &nbsp;doSomething();
 * </code></p>
 * <p>
 * Instead, code is written like:</p>
 * <code>
 * unless(booleanExpression)<br>
 * &nbsp; &nbsp;.do_(action);
 * </code>
 * <p>
 * Where action is a Runnable function.</p>
 * <p>
 * Oftentimes, this will lead to slightly more readable code.  Unfortunately,
 * due to this not being a built-in control structure, there are some limitations
 * to what it can do.  For one, you cannot insert a {@code break} or 
 * {@code continue} statement into {@code do_}.  This structure should work for
 * just about anything else you want to do, though.
 */
public class UnlessStatement
{
	/**
	 * Starts off the unless statement, taking in a boolean expression.
	 * @param expression - a boolean expression, which, if false, will trigger the
	 * action in the {@code do_} method.
	 */
	public static UnlessStatement unless(boolean expression)
	{
		return new UnlessStatement(expression);
	}
	
	/**
	 * An unless statement without the {@code do_} method.  Instead, just put the
	 * action you want as the second parameter and you're done.
	 * <p>
	 * For example, instead of this:</p>
	 * <code>
	 * unless(booleanExpression)<br>
	 * &nbsp; &nbsp;.do_(action);
	 * </code>
	 * <p>
	 * You can write this:</p>
	 * <p><code>
	 * unless(booleanExpression, action)
	 * </code></p>
	 * @param expression - a boolean expression, which, if false, will trigger the
	 * action
	 * @param action - action to perform if the boolean expression evaluates as
	 * false
	 */
	public static void unless(boolean expression, Runnable action)
	{
		new UnlessStatement(expression).do_(action);
	}
	
	/**
	 * The second half of the unless statement, taking in a 
	 * {@link java.lang.Runnable Runnable} action for what should be done if the
	 * boolean expression evaluates as false
	 * @param action - action to perform if the boolean expression evaluates as
	 * false
	 */
	public void do_(Runnable action)
	{
		if(!expression)
		{
			action.run();
		}
	}	
	
	//***************************************************************************
	// Private fields and constructor
	//***************************************************************************
	private boolean expression;
	
	private UnlessStatement(boolean expression)
	{
		this.expression = expression;
	}
}
