package func.java.controlflow;

import static func.java.controlflow.SwitchStatementFactory.switch_;

public class SwitchQuickTest
{
	public static void main(String[] args)
	{
		switch_()
			.case_(() -> true)
				.then_(SwitchQuickTest::case1)
				.continue_()
			.case_(() -> false)
				.then_(SwitchQuickTest::case2pt1)
				.then_(SwitchQuickTest::case2pt2)
				.continue_()
			.default_()
				.then_(SwitchQuickTest::defaultCase)
		.go_();
	}
	
	public static void case1()
	{
		System.out.println("case 1");
	}
	
	public static void case2pt1()
	{
		System.out.println("case 2 part 1");
	}
	
	public static void case2pt2()
	{
		System.out.println("case 2 part 2");
	}
	
	public static void defaultCase()
	{
		System.out.println("default case");
	}
}
