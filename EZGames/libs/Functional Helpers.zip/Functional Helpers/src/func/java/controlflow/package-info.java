package func.java.controlflow;
//TODO: organize, document, and test all these.