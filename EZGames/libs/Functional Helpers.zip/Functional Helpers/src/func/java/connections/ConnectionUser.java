package func.java.connections;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.Consumer;
import java.util.function.Function;

public class ConnectionUser
{
	public ConnectionUser(Connection connection)
	{
		this.connection = connection;
	}
	
	public void useConnection(Consumer<Connection> connectionUser) throws SecurityException, SQLException
	{
		try(Connection conn = connection)
		{
			connectionUser.accept(conn);
		}
		catch(SecurityException | SQLException e)
		{
			throw e;
		}
	}
	
	public <T> T useConnection(Function<Connection, T> connectionUser) throws SecurityException, SQLException
	{
		try(Connection conn = connection)
		{
			return connectionUser.apply(conn);
		}
		catch(SecurityException | SQLException e)
		{
			throw e;
		}
	}
	
	private Connection connection;
}
